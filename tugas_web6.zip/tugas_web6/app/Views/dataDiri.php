<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Diri</title>
    <!-- Link Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h3>Data Diri</h3>
            </div>
            <div class="card-body">
                <?php
                // Data diri
                $nama = "Muhammad Satrio Prayoga";
                $usia = 19;
                $alamat = "Desa Wonosari, Kecamatan Siwalan, Kabupaten Pekalongan";
                $telepon = "081234567890";
                $email = "Satrio123@gmail.com";
                ?>
                <ul class="list-group">
                    <li class="list-group-item"><strong>Nama :</strong> <?= $nama; ?></li>
                    <li class="list-group-item"><strong>Usia :</strong> <?= $usia; ?></li>
                    <li class="list-group-item"><strong>Alamat :</strong> <?= $alamat; ?></li>
                    <li class="list-group-item"><strong>Nomor Telepon :</strong> <?= $telepon; ?></li>
                    <li class="list-group-item"><strong>Email :</strong> <?= $email; ?></li>
                </ul>
            </div>
        </div>
        <div class="mt-4">
        <a href="welcome_message" class="btn btn-secondary">Kembali</a>
        </div>
        
    </div>

    <!-- Link Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
